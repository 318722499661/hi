#!/bin/sh

export QTWB_DIR="/mnt/mmc/MUOS/application/.dolphin"
export LD_LIBRARY_PATH="$QTWB_DIR/lib:/usr/lib"
export LD_PRELOAD="/mnt/mmc/MUOS/application/.dolphin/lib/libmathlib.so /mnt/mmc/MUOS/application/.dolphin/lib/libstringlib.so"

if pgrep -f "playbgm.sh" >/dev/null; then
        killall -q "playbgm.sh" "mp3play"
fi

if pgrep -f "muplay" >/dev/null; then
        killall -q "muplay"
        rm "$SND_PIPE"
fi

echo app >/tmp/act_go

. /opt/muos/script/var/func.sh

export HOME="/mnt/mmc/MUOS/application/.dolphin"

echo "dolphin" >/tmp/fg_proc

# Do it twice, it's just as nice!
cat /dev/zero > /dev/fb0 2>/dev/null
cat /dev/zero > /dev/fb0 2>/dev/null

export GPTOKEYB="$QTWB_DIR/gptokeyb"

cd "$QTWB_DIR" || exit

echo "dolphin" >/tmp/fg_proc

echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo performance > /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
echo performance > /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
echo performance > /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor

echo 648000000 > /sys/devices/platform/gpu/devfreq/gpu/max_freq

SDL_GAMECONTROLLERCONFIG=$(grep "Deeplay" "/usr/lib32/gamecontrollerdb.txt") $GPTOKEYB xbox360 -k "./dolphin" & nice -n -10 ./dolphin -e boot.dol -u /mnt/mmc/MUOS/application/.dolphin
